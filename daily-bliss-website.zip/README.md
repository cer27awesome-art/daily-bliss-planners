# Daily Bliss Planners

Daily Bliss Planners is an online store website for selling customizable digital planners in PDF format. These planners help users stay organized and motivated with multiple templates and color options.

## Features
- Clean and responsive website design
- Buy Now button linked to a sample PDF
- Easy to customize with your own branding and product

## Tech Stack
- HTML, CSS, JavaScript
- GitHub Pages for free hosting

## Usage
1. Clone this repository
2. Replace `sample_planner.pdf` with your own PDF
3. Update Buy Now link if using Gumroad or Payhip
4. Deploy on GitHub Pages, Netlify, or Vercel

## License
MIT License
